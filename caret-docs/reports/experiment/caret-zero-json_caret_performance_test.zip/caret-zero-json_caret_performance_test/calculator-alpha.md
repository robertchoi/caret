
Tokens: up 1.0k  down 19.1k
Cache:+33.5k  196.1k
Context Window:  33.9k / 200.0k
API Cost:$0.4747


| Time (GMT+9)        | ID                             | Model                        | Workspace                                                                                    | Input  <br>Tokens | Output  <br>Tokens | Type      | Request |
| ------------------- | ------------------------------ | ---------------------------- | -------------------------------------------------------------------------------------------- | ----------------- | ------------------ | --------- | ------- |
| 2025-04-03 12:11:26 | `req_01Cw84sFRQ6vA7AcvpaQTN2D` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 33540             | 395                | Streaming |         |
| 2025-04-03 12:11:14 | `req_01Hqr3AfBUy8hznQXceNY2kH` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 32399             | 722                | Streaming |         |
| 2025-04-03 12:10:38 | `req_014u2Fpus4Li6jBwsBq578Uo` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 27494             | 2383               | Streaming |         |
| 2025-04-03 12:10:20 | `req_01TZEHR2K2mnkuDwfXaH8GE9` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 25079             | 1103               | Streaming |         |
| 2025-04-03 12:10:08 | `req_01363JsHztdMHQfDEJmfFP3E` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 23615             | 628                | Streaming |         |
| 2025-04-03 12:09:47 | `req_01BvDaF7wRyKhxuoJYX2n8G3` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 20919             | 1268               | Streaming |         |
| 2025-04-03 12:09:27 | `req_018FzyMg1TFFabQ7F29fGht5` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 18353             | 1219               | Streaming |         |
| 2025-04-03 12:09:02 | `req_01GSqyvKXmrP9VK2UnQpsmpo` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 16290             | 1808               | Streaming |         |
| 2025-04-03 12:08:24 | `req_01UMEEGRZFv6SR6xSovdiEgn` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 13484             | 2551               | Streaming |         |
| 2025-04-03 12:07:59 | `req_01EjoVSNuwK6tEUVWqq6Xws7` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 9902              | 1732               | Streaming |         |
| 2025-04-03 12:07:14 | `req_01Mi2pv6Z5nExoftBrSUUhCx` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 6237              | 3421               | Streaming |         |
| 2025-04-03 12:06:44 | `req_0156nmqTrE4reZFCPKui8iPL` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 2414              | 1892               | Streaming |         |
| 2025-04-03 12:06:41 | `req_0164CdmRqYYBLRhmuxWnJCrN` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 983               | 184                | Streaming |         |
| 2025-04-03 11:55:32 | `req_013gTae3R31oa8SP9UPZw9r7` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 47578             | 334                | Streaming |         |
| 2025-04-03 11:54:50 | `req_01Lrp6NcNPGFNc8CpEoeCaHm` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 41648             | 2917               | Streaming |         |
| 2025-04-03 11:54:24 | `req_01E9qerghDLVzvV1Q7X3efDB` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 38407             | 1555               | Streaming |         |
| 2025-04-03 11:54:02 | `req_01EtkD5JxU3P49fnV4EkhHDw` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 35520             | 1348               | Streaming |         |
| 2025-04-03 11:53:44 | `req_01SkZffkRbz4vyq15DUXwcM1` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 33484             | 981                | Streaming |         |
| 2025-04-03 11:53:11 | `req_01GbmaSQPpvLGBsCCHqhnHcA` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 28738             | 2370               | Streaming |         |
| 2025-04-03 11:52:29 | `req_012D7cdakFmC5rqMVHzKd9Ph` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 22489             | 3136               | Streaming |         |


