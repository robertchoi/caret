@/comparison-instructions.md 알파야 작업 부탁해

Tokens: up 48  down 10.1k
Cache:+33.6k182.1k
Context Window: 34.2k / 200.0k
API Cost:$0.3322



| Time (GMT+9)        | ID                             | Model                        | Workspace                                                                                    | Input  <br>Tokens | Output  <br>Tokens | Type      | Request |
| ------------------- | ------------------------------ | ---------------------------- | -------------------------------------------------------------------------------------------- | ----------------- | ------------------ | --------- | ------- |
| 2025-04-03 14:18:42 | `req_01L2HMPEdq6xstKXbspi8N1q` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 33586             | 632                | Streaming |         |
| 2025-04-03 14:18:28 | `req_01G1JhtpXBtxfAsg46BjxQjh` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 32407             | 810                | Streaming |         |
| 2025-04-03 14:17:48 | `req_01Sp8pQyvVhTEgQqgb86nv6q` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 26910             | 2675               | Streaming |         |
| 2025-04-03 14:17:28 | `req_015KQ6ufXvWTMQ5YGJn6aTa9` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 24440             | 1175               | Streaming |         |
| 2025-04-03 14:17:10 | `req_01GmjSDgrW4pq1FSF71GwrXr` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 22421             | 955                | Streaming |         |
| 2025-04-03 14:16:47 | `req_01SqWtaTzHVnPu9Kv8bCRufr` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 19396             | 1451               | Streaming |         |
| 2025-04-03 14:16:36 | `req_0128US4rsfDt9PXRtsGEXtuq` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 18395             | 449                | Streaming |         |
| 2025-04-03 14:16:10 | `req_01VJem7FpHg5qYh5w7GhkCVM` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 14343             | 2097               | Streaming |         |
| 2025-04-03 14:15:46 | `req_01FWButSnSz8ZhPxouc2Md2j` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 10632             | 1790               | Streaming |         |
| 2025-04-03 14:15:12 | `req_014f8Pvkt7g4pY1WxkHxp9YR` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 7432              | 2904               | Streaming |         |
| 2025-04-03 14:14:43 | `req_01XuXk9AGyKYkY32jsaCvHzz` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 3039              | 2294               | Streaming |         |
| 2025-04-03 14:14:39 | `req_01KUprocUWNeeEcxU37NAw3Y` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 2767              | 149                | Streaming |         |



