# Logs

Last refresh time: April 3, 2025 at 2:34 PM GMT+9

| Time (GMT+9)        | ID                             | Model                        | Workspace                                                                                    | Input  <br>Tokens | Output  <br>Tokens | Type      | Request |
| ------------------- | ------------------------------ | ---------------------------- | -------------------------------------------------------------------------------------------- | ----------------- | ------------------ | --------- | ------- |
| 2025-04-03 14:33:23 | `req_01MpsYXUiqbV53Fp3RsnD43B` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 30001             | 461                | Streaming |         |
| 2025-04-03 14:33:16 | `req_01EC79KKyVJy1823yfT9Hser` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 29765             | 181                | Streaming |         |
| 2025-04-03 14:33:07 | `req_01WQEvxc4YjSXiUGjCaF8NmU` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 29089             | 158                | Streaming |         |
| 2025-04-03 14:32:36 | `req_01JXG3Zz9Q2VYwdPPM2vrWoK` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 28642             | 159                | Streaming |         |
| 2025-04-03 14:32:05 | `req_01VW6nJNzYoLtyiam58ZWhch` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 24367             | 2105               | Streaming |         |
| 2025-04-03 14:31:43 | `req_018su5X1A79fQLJKGKNsxU63` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 21484             | 1427               | Streaming |         |
| 2025-04-03 14:31:19 | `req_01HcrbjTonX8zHkVTvdwPep3` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 18296             | 1521               | Streaming |         |
| 2025-04-03 14:31:06 | `req_01YHjNneUaWpu8rwujEEncG6` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 17025             | 672                | Streaming |         |
| 2025-04-03 14:30:55 | `req_01Umm7BeKB1ePUX6qeq9fBL5` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 16294             | 409                | Streaming |         |
| 2025-04-03 14:30:34 | `req_013zqoSPJgKtzZdairR1sY6Y` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 13637             | 1298               | Streaming |         |
| 2025-04-03 14:30:06 | `req_01Hx5LLDjkfxX94DvedEpBYm` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 9478              | 2047               | Streaming |         |
| 2025-04-03 14:29:44 | `req_01DUV4oguBpvrXhFGL5tM8xh` | `claude-3-7-sonnet-20250219` | [<br><br>Default<br><br><br><br>](https://console.anthropic.com/settings/workspaces/default) | 6560              | 1500               | Streaming |         |
